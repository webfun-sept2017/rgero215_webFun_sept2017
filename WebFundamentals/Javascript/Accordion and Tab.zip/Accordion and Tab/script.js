$(document).ready(function () {
    $("#tabs").tabs();
    $(".mainContent").accordion();
})
