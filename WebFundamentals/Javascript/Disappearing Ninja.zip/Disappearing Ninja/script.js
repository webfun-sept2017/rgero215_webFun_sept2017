$("document").ready(function () {
    $("img").click(function () {
        $(this).hide();
    })
});
$("document").ready(function () {
    $("button").click(function () {
        location.reload();
    })
});
