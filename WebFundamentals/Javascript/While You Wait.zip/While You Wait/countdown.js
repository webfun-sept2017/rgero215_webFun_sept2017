var daysUntilMyBirthday = 60;

while (daysUntilMyBirthday != 0) {
    daysUntilMyBirthday -= 1;
    if (daysUntilMyBirthday >= 30) {
        console.log(daysUntilMyBirthday, "days it's such a long time for my birthday");
    } else if (daysUntilMyBirthday <= 30 && daysUntilMyBirthday > 5) {
        console.log(daysUntilMyBirthday, "days left and it's almost my birthday");
    } else if (daysUntilMyBirthday <= 5) {
        console.log(daysUntilMyBirthday, "DAYS UNTIL MY BIRTHDAY");
    } 
}
console.log("♪ღ♪*•.¸¸¸.•*¨¨*•.¸¸¸.•*•♪ღ♪¸.•*¨¨*•.¸¸¸.•*•♪ღ♪•*♪ღ♪░H░A░P░P░Y░ B░I░R░T░H░D░A░Y░░♪ღ♪*•♪ღ♪*•.¸¸¸.•*¨¨*•.¸¸¸.•*•♪¸.•*¨¨*•.¸¸¸.•*•♪ღ♪•«");
