//Declare variables of the following types:
//4 Numbers
var x = 33;
var myAge = x;
var dob = 2151984;
var pi = 3.14;
//3 Strings
var firstName = "Ramon";
var lastName = "Geronimo";
var favoriteSport = "Baseball";
//2 Booleans
var isMale = true;
var isSingle = false;
//1 Undefined Variable
var isMarried = undefined;
console.log("Jesus was "+ x +" when he died");
console.log("Is your age " + myAge +"?");
console.log(dob +" This numbers are my DOB");
console.log(pi +" This numbers represent a pi decimal value");
console.log("What is your first name? "+ firstName);
console.log("what is your last name? "+ lastName);
console.log("What's your favorite sport? "+ favoriteSport);
console.log("What's your gender? "+ isMale);
console.log("Are you single? "+isSingle);
console.log("Undefined varible "+ isMarried);
